import vlc
import os

os.add_dll_directory(r"C:\Program Files\VideoLAN\VLC")

songs = {
    "1": "Chug.mp3",
    "2": "Post.mp3",
    "3": "Rick.mp3",
    "4": "Sneaky.mp3",
    "5": "Monkey.mp3"
}

instance = vlc.Instance()
player = instance.media_player_new()

while True:
    print("Choose a song to play:")
    print("1. Chug.mp3")
    print("2. Post.mp3")
    print("3. Rick.mp3")
    print("4. Sneaky.mp3")
    print("5. Monkey.mp3")
    print("Type 'exit' to quit.")

    choice = input("Enter your choice: ")

    if choice.lower() == "exit":
        break

    if choice in songs:
        media = instance.media_new(songs[choice])
        player.set_media(media)
        player.play()
        input("Press Enter to stop playback...")
        player.stop()
    else:
        print("Invalid choice. Please choose a number between 1 and 5 or type 'exit' to quit.")
